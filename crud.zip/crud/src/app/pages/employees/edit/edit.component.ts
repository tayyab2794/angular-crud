import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { EmployeeService } from 'src/app/services/employee.service';
import { Employee } from 'src/app/models/employee.model';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  id: number ;
  header:string ;
  employee: Employee = {
    id: 0,
    name: '',
    email: '',
    phone: 0
  }
  constructor(private router: Router, private route: ActivatedRoute, private employeeServices: EmployeeService) { 
  
  }

  ngOnInit(): void {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.header = this.id=== 0? 'Add Employee': 'Edit Employee';
  
    if(this.id != 0){
      this.employee = this.employeeServices.onGetEmployee(this.id);
    }
  }

  onSubmit(form : NgForm){
    let employee: Employee ={
      id: form.value.id,
      name: form.value.name,
      email: form.value.email,
      phone: form.value.phone
    }
    if(this.id === 0){
      this.employeeServices.onAdd(employee);
    }
    else{
      this.employeeServices.onUpdate(employee);
    }
    this.router.navigateByUrl('');
  }

}
