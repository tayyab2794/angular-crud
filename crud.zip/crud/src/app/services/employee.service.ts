import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees: Employee[] = [
    {
      id: 1,
      name: "ali",
      email: "abc@123.com",
      phone: 1122
    },
    {
      id: 2,
      name: "akram",
      email: "abcdef@123.com",
      phone: 2233
    },
  ];
  constructor() { }

  onGet(){
    return this.employees;
  }
  onGetEmployee(id: Number){
    return this.employees.find(x=>x.id === id);
  }
  onAdd(employee: Employee){
    this.employees.push(employee);
  }
  onDelete(id: Number){
    let employee = this.employees.find(x=>x.id === id);
    let index = this.employees.indexOf(employee,0);
    this.employees.splice(index,1);
  }
  onUpdate(employee: Employee){
    let oldEmployee = this.employees.find(x=>x.id === employee.id);
    oldEmployee.name = employee.name;
    oldEmployee.email = employee.email;
    oldEmployee.phone = employee.phone;
  }
}
