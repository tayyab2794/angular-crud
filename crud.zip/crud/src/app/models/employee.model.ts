export class Employee{
    public id: number = 0;
    public name: string = '';
    public email: string= '';
    public phone: number= 0;

}